
import re
import pickle
import time
import collections
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import math
import os
from collections import OrderedDict

def Modèle_Boolean(Request,Index):
    #liste qui contiendera les documents vérifiés
    Reponse_Documents=[]
    #tokenization de la requête
    Requete_tokens=nltk.tokenize.word_tokenize(Request)  
    #Requete_tokens=['(','eau','and','poisson',')','or','chèvre']
    # stocker dans une liste les termes de la requete sans les operateur 
    Liste_termes_Req=[]
    for exp in Requete_tokens:
            if(exp.lower() not in ['and','or','(',')','not']):
                Liste_termes_Req.append(exp)
   
    #Parcourir tous les documents de l'index
    for doc in Index.keys():
        #print('doc'+str(doc))
        #pour chaque document on a besoin d'une nouvelle copie des tokens de a requete
        #Requete=Requete_tokens 
        Requete=nltk.tokenize.word_tokenize(Request)  
        #Requete=['(','eau','and','poisson',')','and','not','chèvre']
        #print(Liste_termes_Req)
        for terme in Liste_termes_Req:
            #print(terme)
            if(terme in Index[doc].keys()):
                #print(Requete)
                Requete[Requete.index(terme)]='1'
                #print('oui')
            else:
                Requete[Requete.index(terme)]='0'
                #print('non')
        
        String_Requete=" ".join(Requete)
        if(eval(String_Requete))==1:
            Reponse_Documents.append(doc)
            #print(Reponse_Documents)
    return(Reponse_Documents)
 
def traiter_document(var):
    #remplacer les '
    var=var.replace(","," ")
    var=var.replace("."," ")
    var=var.replace("-"," ")
    var=var.replace("!"," ")
    var=var.replace("?"," ")
    var=var.replace(":"," ")
    var=var.replace("="," ")
    var=var.replace("@"," ")
    var=var.replace("&"," ")
    var=var.replace("$"," ")
    var=var.replace("("," ")
    var=var.replace(")"," ")
    var=var.replace("["," ")
    var=var.replace("]"," ")
    var=var.replace("{"," ")
    var=var.replace("}"," ")
    var=var.replace("<"," ")
    var=var.replace(">"," ")
    var=var.replace("'"," ")
    var=var.replace("`"," ")
    var=var.replace("|"," ")
    ponctuation=["\"", "'", "!", "(", ")", "?", ":", "=", ",", ";", ".","`",">","<","}","{","]","[","&","@","|"]

    #decouper le texte en mots et mettre tous les mots en minuscules
    liste_des_mots=word_tokenize(var)
    liste_des_mots = [word.lower() for word in liste_des_mots ]
    
    #supprimer les mots vides
    #print(stopwords.words('english'))
    liste_des_mots = [word for word in liste_des_mots if word not in stopwords.words("english")]

    #supprimer la ponctuation
    liste_des_mots = [word for word in liste_des_mots if word not in ponctuation]

    #supprimer les mots à une seule lettre
    liste_des_mots = [word for word in liste_des_mots if len(word)>1]

    #calcuer la frequence de chaque mot du document et mettre le tout dans un dictionnaire "dict_frequence"
    dict_frequence=dict(collections.Counter(liste_des_mots))

    return(dict_frequence)   

def cleanReq(var):
    var=var.replace(","," ")
    var=var.replace("."," ")
    var=var.replace("-"," ")
    var=var.replace("!"," ")
    var=var.replace("?"," ")
    var=var.replace(":"," ")
    var=var.replace("="," ")
    var=var.replace("@"," ")
    var=var.replace("&"," ")
    var=var.replace("$"," ")
    var=var.replace("("," ")
    var=var.replace(")"," ")
    var=var.replace("["," ")
    var=var.replace("]"," ")
    var=var.replace("{"," ")
    var=var.replace("}"," ")
    var=var.replace("<"," ")
    var=var.replace(">"," ")
    var=var.replace("'"," ")
    var=var.replace("`"," ")
    var=var.replace("|"," ")
    var  = var.lower()
    return var

def codeReq(index):
    dicReq = dict()
    for term in index:
      freq = index[term]
      maximum = max(list(index.values()))
      dicReq[term] = float("{:.3f}".format(freq/maximum))
    return dicReq

def mesureInterne(dic_req,reverse_dic_pondere,nbDocument):
    list_doc = dict()
    #construire une liste des documents selectionnée
    dic_doc = dict()
    for iddoc in range(1,(nbDocument+1)):
        somme = 0
        for word in dic_req:
            #calculer la somme des produits interne 
            if (word,str(iddoc)) in reverse_dic_pondere:
                somme = somme + dic_req[word] * reverse_dic_pondere[(word,str(iddoc))]
        #Ajouter le documents a la liste si la somme est différente de zero
        if somme != 0:
            somme = float("{:.3f}".format((somme)))
            dic_doc[str(iddoc)] = somme
    #triée la liste par ordre decroissant
    return dict(sorted(dic_doc.items(), key=lambda item: item[1],reverse=True))

def mesureDice(dic_req,reverse_dic_pondere,nbDocument):
    list_doc = dict()
    #construire une liste des documents selectionnée
    dic_doc = dict()
    for iddoc in range(1,(nbDocument+1)):
        #initialiser les somme
        somme, sommedoc, sommereq = 0,0,0
        for word in dic_req:
            #calculer la somme des produits interne 
            if (word,str(iddoc)) in reverse_dic_pondere:
                somme = somme + dic_req[word] * reverse_dic_pondere[(word,str(iddoc))]
                sommedoc = sommedoc + pow(reverse_dic_pondere[(word,str(iddoc))],2)
                sommereq = sommereq + pow(dic_req[word],2)
        #Ajouter le documents a la liste si la somme est différente de zero
        if somme != 0:
            somme = float("{:.3f}".format(((2*somme) / (sommedoc+sommereq))))
            dic_doc[str(iddoc)] = somme
    #triée la liste par ordre decroissant
    return dict(sorted(dic_doc.items(), key=lambda item: item[1],reverse=True))

def mesureCosinus(dic_req,reverse_dic_pondere,nbDocument):
    list_doc = dict()
    #construire une liste des documents selectionnée
    dic_doc = dict()
    for iddoc in range(1,(nbDocument+1)):
        #initialiser les somme
        somme, sommedoc, sommereq = 0,0,0
        for word in dic_req:
            #calculer la somme des produits interne 
            if (word,str(iddoc)) in reverse_dic_pondere:
                somme = somme + dic_req[word] * reverse_dic_pondere[(word,str(iddoc))]
                sommedoc = sommedoc + pow(reverse_dic_pondere[(word,str(iddoc))],2)
                sommereq = sommereq + pow(dic_req[word],2)
        #Ajouter le documents a la liste si la somme est différente de zero
        if somme != 0:
            somme = float("{:.3f}".format((somme / math.sqrt(sommedoc*sommereq))))
            dic_doc[str(iddoc)] = somme
    #triée la liste par ordre decroissant
    return dict(sorted(dic_doc.items(), key=lambda item: item[1],reverse=True))

def mesureJacard(dic_req,reverse_dic_pondere,nbDocument):
    list_doc = dict()
    #construire une liste des documents selectionnée
    dic_doc = dict()
    for iddoc in range(1,(nbDocument+1)):
        #initialiser les somme
        somme, sommedoc, sommereq = 0,0,0
        for word in dic_req:
            #calculer la somme des produits interne 
            if (word,str(iddoc)) in reverse_dic_pondere:
                somme = somme + dic_req[word] * reverse_dic_pondere[(word,str(iddoc))]
                sommedoc = sommedoc + pow(reverse_dic_pondere[(word,str(iddoc))],2)
                sommereq = sommereq + pow(dic_req[word],2)
        #Ajouter le documents a la liste si la somme est différente de zero
        if somme != 0:
            somme = float("{:.3f}".format((somme / (sommedoc+sommereq-somme))))
            dic_doc[str(iddoc)] = somme
    #triée la liste par ordre decroissant
    return dict(sorted(dic_doc.items(), key=lambda item: item[1],reverse=True))

def Modèle_Vectoriel(req,reverse_dic_pondere,nbDocument,methode):
    if methode == 1:
        return(mesureInterne(req,reverse_dic_pondere,nbDocument))
    elif methode == 2:
        return(mesureDice(req,reverse_dic_pondere,nbDocument))
    elif methode == 3:
        return(mesureCosinus(req,reverse_dic_pondere,nbDocument))
    elif methode == 4:
        return(mesureJacard(req,reverse_dic_pondere,nbDocument))
    


infile3 = open("Fichier_inverse_pondere",'rb')
reverse_dic_pondere= pickle.load(infile3) 
print(len(reverse_dic_pondere))
"""
requete="comunication language software algebraic preliminary"
indexreq=traiter_document(requete)
dicreq=codeReq(indexreq)

nbDoc = 3204
reponse=Modèle_Vectoriel(dicreq,reverse_dic_pondere,nbDoc,2)
print(reponse)
"""

