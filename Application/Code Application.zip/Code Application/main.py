import sys
import pickle
import platform
from PySide2 import QtCore, QtGui, QtWidgets
from PySide2.QtCore import (QCoreApplication, QPropertyAnimation, QDate, QDateTime, QMetaObject, QObject, QPoint, QRect, QSize, QTime, QUrl, Qt, QEvent)
from PySide2.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase, QIcon, QKeySequence, QLinearGradient, QPalette, QPainter, QPixmap, QRadialGradient)
from PySide2.QtWidgets import *
import os
from app_modules import *
import sqlite3
from reportlab.lib.pagesizes import letter
from Modèles import Modèle_Boolean
import Modèles 
import datetime
import time
class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

       
        

        ## REMOVE ==> STANDARD TITLE BAR
        UIFunctions.removeTitleBar(True)
        ## ==> END ##

        ## SET ==> WINDOW TITLE
        self.setWindowTitle('Main Window - Python Base')
        UIFunctions.labelTitle(self, 'Main Window - Python Base')
        UIFunctions.labelDescription(self, 'Set text')
        ## ==> END ##

        ## REMOVE ==> STANDARD TITLE BAR
        startSize = QSize(1000, 720)
        self.resize(startSize)
        self.setMinimumSize(startSize)
        
        self.ui.btn_toggle_menu.clicked.connect(lambda: UIFunctions.toggleMenu(self, 220, True))
        ## ==> END ##

        ## ==> ADD CUSTOM MENUS
        
        self.ui.spinBox_2.setMinimum(1)
        self.ui.spinBox_2.setMaximum(64)

        def Afficher_index():
            infile3 = open("Index",'rb')
            index= pickle.load(infile3) 
            self.ui.tableWidget_6.setRowCount(0)
            for row_number, key in enumerate(index):
                self.ui.tableWidget_6.insertRow(row_number)
                lis=["Document"+str(key),index[key]]
                for column_number, data in enumerate(lis):
                    self.ui.tableWidget_6.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)) )
              

        def Afficher_inverse():
            infile3 = open("Fichier_inverse_meth1",'rb')
            inverse= pickle.load(infile3) 
            self.ui.tableWidget_6.setRowCount(0)
            for row_number, key in enumerate(inverse):
                self.ui.tableWidget_6.insertRow(row_number)
                lis=[key,inverse[key]]
                for column_number, data in enumerate(lis):
                    self.ui.tableWidget_6.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)) )

        #TODO               Fichier pondéré 
        def Afficher_inverse_pondéré():
            infile3 = open("Fichier_inverse_pondere",'rb')
            inverse= pickle.load(infile3) 
            self.ui.tableWidget_6.setRowCount(0)
            for row_number, key in enumerate(inverse):
                self.ui.tableWidget_6.insertRow(row_number)
                lis=[key,inverse[key]]
                for column_number, data in enumerate(lis):
                    self.ui.tableWidget_6.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)) )

        def Afficher_termes():
            infile2 = open("tokens",'rb')
            tokens= pickle.load(infile2) 
            self.ui.tableWidget_6.setRowCount(0)
            for row_number, key in enumerate(tokens):
                self.ui.tableWidget_6.insertRow(row_number)
                liste_doc=[]
                for doc in tokens[key]:
                    liste_doc.append("Document N° "+str(doc))

                lis=[key,liste_doc]
                for column_number, data in enumerate(lis):
                    self.ui.tableWidget_6.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)) )

        def Avant_experimentation():
            NumRequete=self.ui.spinBox_2.text()
            infile2 = open("precisionResult",'rb')
            precision= pickle.load(infile2) 
            infile3 = open("recallResult",'rb')
            recall= pickle.load(infile3) 
            infile4 = open("ResultatCosinus",'rb')
            resultCos= pickle.load(infile4) 

            self.ui.lineEdit_8.setText(str(precision[NumRequete])) 
            self.ui.lineEdit_9.setText(str(recall[NumRequete]))   

            dic=resultCos[int(NumRequete)][0]

            self.ui.tableWidget_9.setRowCount(0)
            for row_number, key in enumerate(dic):
                self.ui.tableWidget_9.insertRow(row_number)
                lis=["Document N° "+str(key),dic[key]]
                for column_number, data in enumerate(lis):
                    self.ui.tableWidget_9.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)) )

        def Apres_experimentation():
            NumRequete=self.ui.spinBox_2.text()
            infile2 = open("SeuilApresExperimentation",'rb')
            dict1= pickle.load(infile2) 

            infile2 = open("SeuilRequetteGlobal",'rb')
            dict2= pickle.load(infile2) 

            seuil=dict1[int(NumRequete)]


            recall=dict2[NumRequete,seuil][0]


            precision=dict2[NumRequete,seuil][1]


            self.ui.lineEdit_8.setText(str(precision)) 
            self.ui.lineEdit_9.setText(str(recall)) 

            dict3={}
            dict3['Seuil']=seuil

            self.ui.tableWidget_9.setRowCount(0)
            for row_number, key in enumerate(dict3):
                self.ui.tableWidget_9.insertRow(row_number)
                lis=[str(key),dict3[key]]
                for column_number, data in enumerate(lis):
                    self.ui.tableWidget_9.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)) )

        def Rechercher_document():
            NumDoc= str(self.ui.lineEdit_10.text() )
            infile3 = open("Index",'rb')
            index= pickle.load(infile3)
            self.ui.listWidget_3.clear()
            
            if(NumDoc not in index.keys()):
                self.ui.listWidget_3.addItem("Ce document n'existe pas dans la collection.")
            else:
                start_time = time.time()
                self.ui.listWidget_3.addItem(str(index[NumDoc] ))

                interval = time.time() - start_time  
                temp="Temps de réponse :%.02f" % (interval)+" secondes"
                self.ui.listWidget_3.addItem(str(temp))

        def Rechrcher_terme():
            self.ui.listWidget_3.clear()
            mot= str(self.ui.lineEdit_6.text() )
            infile3 = open("Fichier_inverse_meth1",'rb')
            inverse= pickle.load(infile3) 

            start_time = time.time() 
            trouver=False
            for key in inverse.keys():
                if(key[0]) == mot:
                    trouver=True
                    self.ui.listWidget_3.addItem("Document "+str(key[1])+"   ------>  Frequence d'apparirion: "+str(inverse[key]))

            

            if(trouver==False):
                self.ui.listWidget_3.addItem("Ce mot n'existe pas dans la collection.")


            interval = time.time() - start_time  
            temp="Temps de réponse :%.02f" % (interval)+" secondes"
            self.ui.listWidget_3.addItem(str(temp))



        def Résultat_boolean():
            self.ui.listWidget.clear()
            infile3 = open("Index",'rb')
            index= pickle.load(infile3)
            start_time = time.time()
            requete= str(self.ui.lineEdit_5.text() ).lower()  
            resultat=Modèle_Boolean(requete,index)
            interval = time.time() - start_time  
            temp="Temps de réponse :%.02f" % (interval)+" secondes"
            self.ui.tableWidget_8.setRowCount(0)
            
            for row_number, numdoc in enumerate(resultat):
                self.ui.tableWidget_8.insertRow(row_number)
                termes=[]
                for terme in index[numdoc].keys():
                        termes.append(terme)
                self.ui.listWidget.addItem("Document  "+str(numdoc) )
                lis=["Document  "+str(numdoc),termes]
                for column_number, data in enumerate(lis):
                    self.ui.tableWidget_8.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)) )
                
            self.ui.listWidget.addItem(str(temp ))
                

        def Résultat_vectoriel():
            self.ui.listWidget_2.clear()
            requete= str(self.ui.lineEdit_4.text() ).lower()  
            if(self.ui.radioButton_2.isChecked()):  #Cosinus
                methode=3
            if(self.ui.radioButton_5.isChecked()):  #jacquar
                methode=4
            if(self.ui.radioButton_4.isChecked()):  #produit interne
                methode=1
            if(self.ui.radioButton_6.isChecked()):  #Coef de Dice
                methode=2

            start_time = time.time() 

            infile3 = open("Fichier_inverse_pondere",'rb')
            reverse_dic_pondere= pickle.load(infile3) 

            indexreq=Modèles.traiter_document(requete)
            dicreq=Modèles.codeReq(indexreq)


            nbDoc = 3204
            
            reponse=Modèles.Modèle_Vectoriel(dicreq,reverse_dic_pondere,nbDoc,methode)
            interval = time.time() - start_time  
  

            for doc in reponse.keys():
                self.ui.listWidget_2.addItem("Document  "+str(doc)+"-----> Similarité: "+str(reponse[doc]) )
            
            temp=" %.02f" % (interval)+" secondes"
            self.ui.lineEdit_7.setText(temp)     


            


    

        
       




         
       
        
        self.ui.pushButton_5.clicked.connect(Afficher_index) 
        self.ui.pushButton_6.clicked.connect(Afficher_inverse)
        self.ui.pushButton_8.clicked.connect(Résultat_boolean) 
        self.ui.pushButton_7.clicked.connect(Résultat_vectoriel) 
        self.ui.pushButton_9.clicked.connect(Afficher_inverse_pondéré) 
        self.ui.pushButton_10.clicked.connect(Avant_experimentation) 
        self.ui.pushButton_11.clicked.connect(Apres_experimentation) 
        self.ui.pushButton_12.clicked.connect(Afficher_termes) 
        self.ui.pushButton_13.clicked.connect(Rechrcher_terme) 
        self.ui.pushButton_14.clicked.connect(Rechercher_document) 
        
          



        self.ui.stackedWidget.setMinimumWidth(20)
        UIFunctions.addNewMenu(self, "Fonctions\n d'accès ", "btn_acces", "url(:/16x16/icons/16x16/cil-user-follow.png)", True)
        UIFunctions.addNewMenu(self, "Modèle \n  boolean", "btn_new_user", "url(:/16x16/icons/16x16/cil-user-follow.png)", True)
        UIFunctions.addNewMenu(self, "Modèle \n vectoriel", "btn_widgets", "url(:/16x16/icons/16x16/cil-equalizer.png)", True)
        UIFunctions.addNewMenu(self, "Consulter \n les index", "btn_home", "url(:/16x16/icons/16x16/cil-home.png)", True)
        
        UIFunctions.addNewMenu(self, "Evaluation", "btn_eval", "url(:/16x16/icons/16x16/cil-equalizer.png)", True)
        ## ==> END ##

        # START MENU => SELECTION
        UIFunctions.selectStandardMenu(self, "btn_home")
        ## ==> END ##

        ## ==> START PAGE
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_7)
        ## ==> END ##

        ## USER ICON ==> SHOW HIDE
        #UIFunctions.userIcon(self, "TK", "", True)
        ## ==> END ##


        ## ==> MOVE WINDOW / MAXIMIZE / RESTORE
        ########################################################################
        def moveWindow(event):
            # IF MAXIMIZED CHANGE TO NORMAL
            if UIFunctions.returStatus() == 1:
                UIFunctions.maximize_restore(self)

            # MOVE WINDOW
            if event.buttons() == Qt.LeftButton:
                self.move(self.pos() + event.globalPos() - self.dragPos)
                self.dragPos = event.globalPos()
                event.accept()

        # WIDGET TO MOVE
        self.ui.frame_label_top_btns.mouseMoveEvent = moveWindow
       
        UIFunctions.uiDefinitions(self)
        ## ==> END ##

        self.show()


        self.ui.tableWidget.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        


    def Button(self):
        # GET BT CLICKED
        btnWidget = self.sender()
        # PAGE NEW USER
        if btnWidget.objectName() == "btn_acces":
            self.ui.stackedWidget.setCurrentWidget(self.ui.page_3)
            UIFunctions.resetStyle(self, "btn_acces")
            UIFunctions.labelPage(self, "Fonction \n d'accès")
            btnWidget.setStyleSheet(UIFunctions.selectMenu(btnWidget.styleSheet()))
        # PAGE Modele
        if btnWidget.objectName() == "btn_new_user":
            self.ui.stackedWidget.setCurrentWidget(self.ui.page_5)
            UIFunctions.resetStyle(self, "btn_new_user")
            UIFunctions.labelPage(self, "Modèle boolean")
            btnWidget.setStyleSheet(UIFunctions.selectMenu(btnWidget.styleSheet()))
            # PAGE historique
        if btnWidget.objectName() == "btn_home":
            self.ui.stackedWidget.setCurrentWidget(self.ui.page_6)
            UIFunctions.resetStyle(self, "btn_home")
            UIFunctions.labelPage(self, "Consulter index")
            btnWidget.setStyleSheet(UIFunctions.selectMenu(btnWidget.styleSheet()))

        
        

        # PAGE recap
        if btnWidget.objectName() == "btn_widgets":
            self.ui.stackedWidget.setCurrentWidget(self.ui.page_2)
            UIFunctions.resetStyle(self, "btn_widgets")
            UIFunctions.labelPage(self, "Modèle vectoriel")
            btnWidget.setStyleSheet(UIFunctions.selectMenu(btnWidget.styleSheet()))

        if btnWidget.objectName() == "btn_eval":
            self.ui.stackedWidget.setCurrentWidget(self.ui.page)
            UIFunctions.resetStyle(self, "btn_eval")
            UIFunctions.labelPage(self, "Evaluation")
            btnWidget.setStyleSheet(UIFunctions.selectMenu(btnWidget.styleSheet()))

   
  
    
    ## ==> END ##

    ## EVENT ==> RESIZE EVENT
    ########################################################################
    def resizeEvent(self, event):
        self.resizeFunction()
        return super(MainWindow, self).resizeEvent(event)

    def resizeFunction(self):
        print('Height: ' + str(self.height()) + ' | Width: ' + str(self.width()))
    ## ==> END ##

    ########################################################################
    ## END ==> APP EVENTS
    ############################## ---/--/--- ##############################

if __name__ == "__main__":
    app = QApplication(sys.argv)
    QtGui.QFontDatabase.addApplicationFont('fonts/segoeui.ttf')
    QtGui.QFontDatabase.addApplicationFont('fonts/segoeuib.ttf')
    window = MainWindow()
    sys.exit(app.exec_())



#pyside2-uic.exe inch.ui > ui_main.py

#(preliminary or (report and time)) and not computer